
public class photo {
	private int length;
	private int width;
	
	//default
	public photo() {
		length = 0;
		width = 0;
	}
	
	//primary
	public photo(int len, int wid) {
		this.length = len;
		this.width = wid;
	}
	
	
	//copy
	public photo(photo cpy) {
		length =cpy.length;
		width = cpy.width;
	}
	
	
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	
	
	
}
 
