
public class House {
	private int id;
	protected float price;
	protected String location;
	protected String advertiser;
	protected photo image;
	
	public House() {
		id = 0;
		price = 0;
		location = "";
		advertiser = "";
		image = new photo ();
	}
	
	public House(int idval, float p, String l, String a, photo val){
		id =idval;
		price = p;
		location = l;
		advertiser = a;
		image = new photo(val);
	}

	public House(final House other) {
		id = other.id;
		price = other.price;
		location = other.location;
		advertiser = other.advertiser;
		image = other.image;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAdvertiser() {
		return advertiser;
	}

	public void setAdvertiser(String advertiser) {
		this.advertiser = advertiser;
	}

	public photo getImage() {
		return image;
	}

	public void setImage(photo image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "House [id=" + id + ", price=" + price + ", location=" + location + ", advertiser=" + advertiser
				+ ", image=" + image + "]";
	}
	
	
}


