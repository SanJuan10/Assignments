import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		
		
		House[] housearr = new House[3];
				
		
		Scanner input = new Scanner(System.in);
		
		
	int i;
	
	try {
		FileWriter houseInfo = new FileWriter("houseInfo");
	

		
		for(i=0;i<=2;i++) {
			
			System.out.println("Please enter the id");
			housearr[i].setId(input.nextInt());
			System.out.println("Please enter the price");
			housearr[i].setPrice(input.nextFloat());
			System.out.println("Please enter the location");
			housearr[i].setLocation(input.next());
			System.out.println("Please enter the advertiser");
			housearr[i].setAdvertiser(input.next());
			
		
			
			houseInfo.write("House Id:  "+housearr[i].getId());
			houseInfo.write("House price"+housearr[i].getPrice());
			houseInfo.write("House location"+housearr[i].getLocation());
			houseInfo.write("House advertiser"+housearr[i].getAdvertiser());

		}
		
		
			input.close();
			houseInfo.close();
		} catch (IOException e) {
			System.out.println("An error has occurred with the file.");
			e.printStackTrace();
		}
		
		
	}

}
